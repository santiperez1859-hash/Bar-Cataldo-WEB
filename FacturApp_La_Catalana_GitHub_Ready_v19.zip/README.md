# FacturApp La Catalana

Versión v19 lista para GitHub/Netlify.

Cambios: en el modal Agregar producto, el campo editable ahora es Precio unitario y no Total estimado.
